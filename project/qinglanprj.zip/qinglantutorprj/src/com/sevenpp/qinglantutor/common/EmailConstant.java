package com.sevenpp.qinglantutor.common;

/**
 * 
 * @ClassName: Constant 
 * @Description: 邮箱的配置
 * @author Mr.Ren
 * @date 2018年12月3日 上午9:04:14 
 * @version V1.0 
 */
public class EmailConstant {
	public final static String HOST = "smtp.exmail.qq.com";
	public final static String FROMNAME = "qinglan@javafan.club";
	public final static String PASSWORD = "Renjiahua12345@";
	public final static String REPLYADDRESS = "qinglan@javafan.club";
	public final static String PORT = "465";
	public final static String PROTOCOL = "ssl";
}
