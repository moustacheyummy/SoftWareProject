package com.sevenpp.qinglantutor.common;
/**
*code is far away from bug with the animal protecting
*  ┏┓　　　┏┓
*┏┛┻━━━┛┻┓
*┃　　　　　　　┃ 　
*┃　　　━　　　┃
*┃　┳┛　┗┳　┃
*┃　　　　　　　┃
*┃　　　┻　　　┃
*┃　　　　　　　┃
*┗━┓　　　┏━┛
*　　┃　　　┃神兽保佑
*　　┃　　　┃代码无BUG！
*　　┃　　　┗━━━┓
*　　┃　　　　　　　┣┓
*　　┃　　　　　　　┏┛
*　　┗┓┓┏━┳┓┏┛
*　　　┃┫┫　┃┫┫
*　　　┗┻┛　┗┻┛ 
*　　　
* @author 作者 :Mr.Ren
* @version 创建时间：2018年12月19日 上午10:32:59
* 类说明
*/
public class MessageConstant {
	public final static int APPID = 1400170576;
	public final static String APPKEY = "611310680bf81721f46e002ee62fcbe1";
	public final static int TEMPLATEID = 250020;
	public final static String SMSSIGN = "橙色E时光";
}
