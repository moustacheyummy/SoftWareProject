
package com.sevenpp.qinglantutor.entity;

/**
*
* 项目名称：qinglantutorprj
* 类名称：Userinf
* 类描述：
* 创建人：rain
* 创建时间：2018年12月12日 下午7:47:34
* 修改人：rain
* 修改时间：2018年12月12日 下午7:47:34
* 修改备注：
* @version
*
*/
/**
 *  
 * 
 * @ClassName: Userinf 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @author (作者)  
 * @date 2018年12月12日 下午7:47:34 
 * @version V1.0 
 */
public class Userinf {
	private Integer id;
	private String userImg;
	private String realName;
	private String school;
	private String introduce;
	private String teachAge;
	

	public String getTeachAge() {
		return teachAge;
	}

	public void setTeachAge(String teachAge) {
		this.teachAge = teachAge;
	}

	/**
	 *  
	 * 
	 * @return id 
	 */

	public Integer getId() {
		return id;
	}

	/**
	 *  
	 * 
	 * @return userImg 
	 */

	public String getUserImg() {
		return userImg;
	}

	/**
	 *  
	 * 
	 * @return realName 
	 */

	public String getRealName() {
		return realName;
	}

	/**
	 *  
	 * 
	 * @return school 
	 */

	public String getSchool() {
		return school;
	}

	/**
	 *  
	 * 
	 * @return introduce 
	 */

	public String getIntroduce() {
		return introduce;
	}

	/**
	 *  
	 * 
	 * @param id 要设置的 id 
	 */

	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 *  
	 * 
	 * @param userImg 要设置的 userImg 
	 */

	public void setUserImg(String userImg) {
		this.userImg = userImg;
	}

	/**
	 *  
	 * 
	 * @param realName 要设置的 realName 
	 */

	public void setRealName(String realName) {
		this.realName = realName;
	}

	/**
	 *  
	 * 
	 * @param school 要设置的 school 
	 */

	public void setSchool(String school) {
		this.school = school;
	}

	/**
	 *  
	 * 
	 * @param introduce 要设置的 introduce 
	 */

	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}

}
